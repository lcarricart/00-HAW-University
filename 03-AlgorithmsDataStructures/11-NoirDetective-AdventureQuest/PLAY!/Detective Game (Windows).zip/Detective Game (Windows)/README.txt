1) Download Java 21 for your computer
(Windows) https://download.oracle.com/java/21/latest/jdk-21_windows-x64_bin.exe

2) Run Play.bat