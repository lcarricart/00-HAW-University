Instructions to run the game!

1) Download Java 21 for Mac (x64 DMG Installer)
https://download.oracle.com/java/21/latest/jdk-21_macos-x64_bin.dmg

2) Open the Terminal
- Press Command + Space on your keyboard (Spotlight Search).
- Type Terminal and press Enter.
- A window with a black or white background and text will appear.

3) Type chmod +x (Crucial: Make sure there is a space after the x).

4) Drag the Play.command file from the folder into the Terminal window.
It should automatically look something like: chmod +x /Users/Sarah/Desktop/Game/Play.command

5) Click on the Terminal window and press Enter.
(It won't say "Success" or anything; it will just go to a new line. That means it worked.)



!!!! IF EVERYTHING FAILS !!!!

- Right-click (or Control-click) on Play.command.
- Select Open from the menu.
- A new popup will appear asking, "Are you sure?" -> Click Open.